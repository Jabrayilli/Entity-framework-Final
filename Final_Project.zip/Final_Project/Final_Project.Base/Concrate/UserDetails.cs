﻿using Final_Project.Base.Abstract;

namespace Final_Project.Base.Concrate;
public class UserDetail:BaseEntity
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Surname { get; set; }
    public DateTime BirthDay { get; set; }
}
