﻿using Final_Project.Base.Abstract;

namespace Final_Project.Base.Concrate;

public class User:BaseEntity
{
    public int Id { get; set; }
    public int UserDetailsId { get; set; }
    public UserDetail UserDetails { get; set; }
    public ICollection<Post> Posts { get; set; }
}
