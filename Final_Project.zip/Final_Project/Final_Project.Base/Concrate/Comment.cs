﻿using Final_Project.Base.Abstract;

namespace Final_Project.Base.Concrate;
public class Comment:BaseEntity
{
    public string Text { get; set; }
    public string comment { get; set; }
    public int LikeCount { get; set; }
    public ICollection<Post> Posts { get; set; }
}
