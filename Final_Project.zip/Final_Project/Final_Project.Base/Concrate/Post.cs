﻿using Final_Project.Base.Abstract;

namespace Final_Project.Base.Concrate;
public class Post:BaseEntity
{
    public int Id { get; set; }
    public string Text { get; set; }
    public string comment { get; set; }
    public int LikeCount { get; set; }
    public int UserId { get; set; }
    public User User { get; set; }
    public ICollection<Comment> Comments { get; set;}
}
