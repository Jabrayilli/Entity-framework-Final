﻿using Final_Project.Base.Concrate;
using Final_Project.DAL.Repositories.Concrate;

public class Project
{
    static void Main(string[] args)
    {
        UserDetailsRepository userDetailsRepository = new UserDetailsRepository();
        UserRepository userRepository = new UserRepository();
        PostRepository postRepository = new PostRepository();
        CommentRepository commentRepository = new CommentRepository();

        UserDetail UserDetail = new UserDetail() { 
            Name = "Nihad",
            Surname = "Cabrayili",
            BirthDay = DateTime.Now
        };

        User user1 = new User()
        {
            UserDetailsId = 1
        };

        Post post1 = new Post()
        {
            Text = "jabrayilli1",
            comment = "Step It Academy is the best",
            UserId = 1,
        };

        Comment comment_1 = new Comment()
        {
            Text = "user1232323",
            comment = "Absolutely!",

        };

        userDetailsRepository.Add(UserDetail);
        userRepository.Add(user1);
        postRepository.Add(post1);
        commentRepository.Add(comment_1);

        userDetailsRepository.SaveChanges();
        userRepository.SaveChanges();
        postRepository.SaveChanges();
        commentRepository.SaveChanges();
    }
}