﻿using Final_Project.DAL.Context;
using Final_Project.DAL.Repositories.Concrate;

namespace Final_Project.Main;

public class UnitOfWork
{
    private readonly ProjectDBcontext _context;

    public UnitOfWork(ProjectDBcontext context, UserDetailsRepository userDetailsRepository, UserRepository userRepository, PostRepository postRepository, CommentRepository commentRepository)
    {
        _context = context;
        UserDetailsRepository = userDetailsRepository;
        UserRepository = userRepository;
        PostRepository = postRepository;
        CommentRepository = commentRepository;
    }

    public UserDetailsRepository UserDetailsRepository { get; set; }
    public UserRepository UserRepository { get; set; }
    public PostRepository PostRepository { get; set; }
    public CommentRepository CommentRepository { get; set; }
}
