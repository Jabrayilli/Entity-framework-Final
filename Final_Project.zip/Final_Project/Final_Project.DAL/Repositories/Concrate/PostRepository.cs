﻿using Final_Project.Base.Concrate;

namespace Final_Project.DAL.Repositories.Concrate;

public class PostRepository : BaseRepository<Post>
{

}