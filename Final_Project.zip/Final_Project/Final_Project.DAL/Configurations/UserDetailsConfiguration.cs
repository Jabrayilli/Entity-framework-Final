﻿using Final_Project.Base.Concrate;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Final_Project.DAL.Configurations;

public class UserDetailsConfiguration : IEntityTypeConfiguration<UserDetail>
{
    public void Configure(EntityTypeBuilder<UserDetail> builder)
    {
        builder.HasKey(x => x.Id);

        builder
            .HasOne<User>()
            .WithOne(u => u.UserDetails)
            .HasForeignKey<User>(u => u.UserDetailsId);

    }
}
